
//while Loop
i=0
while(i<5){
    console.log("while Loop "+i);
    i++;
}

i=0
while(i<5){
    console.log("break while Loop "+i);
    if (i==3) break;//break if it reaches 3
    i++;
    
}

i=0
while(i<5){
    
    if (i==3) {
        
        i++;
        continue;
    }
    console.log("continue while Loop "+i);
    i++;
}

//do while
i=0
do{
    console.log("do while "+i);
    i++;
}while(i<5);

i=0
do{
    if(i==3) break;
    console.log("Break do while " +i)
    
    i++;
}while(i<5)

i=0
do{
    if (i==3) {
        
        i++;
        continue;
    }
    console.log("Continue Do while "+i)
    i++;
}while(i<5)

//For loop
for(i=0;i<5;i++){
    console.log("For Loop  "+i)
}

//for of - to access all values with break and continue points
dec=[1,2,3,4,5]
for (output of dec){
    console.log("Declared values "+output);
}

for (output of dec){
    console.log("Declared values break point "+output);
    if(output==3)break;//break point
}

for (output of dec){
    
    if(output==3)
    {
     continue;
    }
    console.log("Declared values continue point "+output);//continue point
    
}

let name = "Deepak";

for(let ch of name){
    console.log(ch);
}

//for in - to access all values with break and continue points

let person = {
  name: "Deepak",
  age: 25,
  city: "Chennai"
};

for (key in person) {
  console.log("Keys "+key);
}

for (value in person) {
  console.log("values " +person[value]);
}

for (keyandValue in person) {
  console.log("Both Keys and values "+keyandValue +":"+ person[keyandValue]);
}

for (key in person) {
  if(key=="age") break
  console.log("break points in Keys " +key);//break point
   
}

for (key in person) {
  if(key=="age") {
    continue;
  }
  console.log("continue points in Keys " +key);//continue point
   
}

arr=["key1","Key2","Key3"]
for (key in arr) 
{  
  console.log("array access " +key);// it will return the index values not actual one
}

//for Each
let arr1 = ['Key1','Key2','Key3'];

arr1.forEach((results)=>{
    console.log("for each access "+results)
})