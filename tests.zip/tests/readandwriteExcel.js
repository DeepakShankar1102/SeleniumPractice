const ExcelJs=require('exceljs')


async function readExcel_WithText(SearchText,FileName) {
    
    const Workbook=new ExcelJs.Workbook();
    await Workbook.xlsx.readFile(FileName);
    const Worksheet = Workbook.getWorksheet('Sheet1');
        Worksheet.eachRow((row,rowNumber)=>{

        row.eachCell((cell,ColNumber)=>{
              if(cell.value==SearchText){

               
              
               console.log(rowNumber);
               console.log(ColNumber);
               
                

              }
           

        })

        
    })

  

    
    
}

readExcel_WithText("Apple",'/Playwright_automation_2/test_resources/download_2.xlsx')



async function readExcel_WithValues(Value1,Value2,FileName) {
    
    const Workbook=new ExcelJs.Workbook();
    await Workbook.xlsx.readFile(FileName);
    const Worksheet = Workbook.getWorksheet('Sheet1');

        Worksheet.eachRow((row, rowNumber) => {

        row.eachCell((cell, cellNumber) => {

            if (rowNumber== Value1 && cellNumber==Value2) {

               console.log(cell.value);
               


            }


        })

    })
}

//readExcel_WithValues(3,2,'/Playwright_automation_2/test_resources/download_2.xlsx')


async function ReadandWriteExcel(SearchText,ReplaceText,FileName) {
    
    const Workbook=new ExcelJs.Workbook();
    await Workbook.xlsx.readFile(FileName);
    const Worksheet = Workbook.getWorksheet('Sheet1');

        Worksheet.eachRow((row, rowNumber) => {

        row.eachCell((cell, cellNumber) => {

            if(cell.value==SearchText){

                cell.value=ReplaceText;

            }

            


        })

    })

   await Workbook.xlsx.writeFile(FileName);


}

//ReadandWriteExcel("Kivi","Amla",'/Playwright_automation_2/test_resources/download_2.xlsx')



