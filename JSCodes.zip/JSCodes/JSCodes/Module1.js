export let fn1=()=>{

    let a= 5;
    let b= 70;
    let c= a+b;
    console.log(typeof(a));
    
    return c;

}

export let fn2=()=>{

    let a= 5;
    let b= 70;
   let c= a-b;
    return c;

}

export let fn3=()=>{

    let a= 5;
    let b= 70;
    let c= a*b;
    return c;

}

//without arrow Function
/*export default function  fn4(){

    let a= 70;
    let b= 5;
    let c= a/b;
    return c;

}*/

//With Arrow Function
let fn5=()=>{

    let a= 100;
    let b= 5;
    let c= a/b;
    return c;


}

export default fn5


console.log(fn1());



//export {fn1, fn2, fn3}-- Exp ort all in single line (one by one)
// export * as Exp1 from "./Module1.js" -- Export all

export * as Mod1 from './Module.js'




