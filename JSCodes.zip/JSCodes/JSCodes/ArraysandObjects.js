let names=["IBS","Software","Chennai"];

names[1]="Software pvt";
console.log(names[1]);

names=["acc","pvt","chennai"];


names[1]="soln pvt";
console.log(names[1]);

names.forEach(output=> console.log( "Printing " +output));

let employee={
    name:'deepak',
    age:'25'
}

console.log(employee.name);

let employee1=[
{
    name:'deepak1',
    age:'26'
},
{
    name:'deepak2',
    age:'27'
}
];
console.log(employee1[1].name);
console.log(employee1);
employee1.forEach(printing2=> console.log("printing2 output "+printing2.name, printing2.age))
employee1.forEach(printing3=> console.log("printing3 output "+JSON.stringify(printing3)))

console.log(employee1.find(user=>user.name==='deepak2').age)
let age1=employee1.find(user=>user.name==='deepak1').age
console.log(age1)


