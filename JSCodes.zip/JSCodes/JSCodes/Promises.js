let PR=new Promise((resolve,reject)=>{
     let internet= true
      if(internet){
        resolve("connected")
      }
      else{
        reject(new Error("Error thrown"))
      }

   
})

 PR.then(data1=> console.log(data1))


 let function1=(()=>{
    let a=7
    let b=8
    c=a+b;
    return c;
 })

 let info=[{name:"Deepak",age:"27"}]
 
 let function2=(()=>{
       // let opname= info[0].name
        // console.log(opname);
        // return opname;
        console.log(info[0].name)
          
})
function2()

let PR5=new Promise((resolve,reject)=>{

 console.log("Printing name "+function2());

    if(function2()==="Deepak"){

        resolve("Name is correct");
        

    }
    else{
        reject("Name is Incorrect");
    }

})

PR5.then(op=>console.log(op)).catch(error=>console.log(error))

 

 let PR3=new Promise((resolve,reject)=>{
     console.log(function1());
     if(function1()===15)
        {
        resolve("PASS")
        
     }
     else{
         reject("FAIL");
     }
 })
 PR3.then(data4=> console.log(data4))
 

let PR2=new Promise((resolve,reject)=>{

   PR.then(data1=> {
       console.log(data1)//connected
       if (data1==="connected")
       {
        resolve("Verified")
       }
       else{
        reject("Not verified")
       }

   }


   )

})


PR2.then(data2=> console.log(data2)).catch(error=> console.log(error))


let PR4 = new Promise((resolve, reject) => {

    let internet = true

    if (internet) {
        resolve("Connected")
    }
    else {
        reject("No Internet")
    }

})

console.log(PR4)

//Promises new code
let fn2=()=>{
    a=10
    b=15
    c=a+b
    return c

 }
 
 
 let PR6=new Promise((resolve,reject)=>{

    ans=fn2()
    console.log("Function return "+fn2());
    
    if(ans===20){
        resolve("solution came")
    }
    else{
        reject("No Solution")
    }
     

 })

 PR6.then(data=>console.log(data))
     .catch(error=>console.log(error))




 





