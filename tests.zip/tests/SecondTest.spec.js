const { test, expect } = require('@playwright/test');
const { log } = require('node:console');
const { TIMEOUT } = require('node:dns');




test('Testcase-1- Login with Invalid Credential', async function ({ browser }) {

  const context = await browser.newContext()
  const page = await context.newPage();
  await page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");


  await expect(page).toHaveTitle("OrangeHRM")
  await page.locator("[placeholder='Username']").fill("DeepakShankar")
  await page.locator("[placeholder='Password']").fill("DeepakShankar")
  await page.locator("[type='submit']")
  const btntext = await page.locator("[type='submit']").textContent()
  console.log(btntext);
  await page.locator("[type='submit']").click();

  const notification_message = await page.locator('p.oxd-alert-content-text').textContent();
  console.log(notification_message);
  await expect(page.locator('p.oxd-alert-content-text')).toContainText("Invalid credentials");



})

test('Testcase-2- Multiple element visiblity', async ({ browser }) => {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.demoblaze.com/");

  await expect(page).toHaveTitle("STORE");

  await page.locator(".nav-link").nth(0).click();


  const phonedetail1 = await page.locator('.card-title').nth(0).textContent();

  const phonedetail2 = await page.locator('.card-title').first().textContent();

  const phonedetail3 = await page.locator('.card-title').last().textContent();

  console.log(phonedetail1);
  console.log(phonedetail2);
  console.log(phonedetail3);

  //To print all titles

  const allTitles = await page.locator('.card-title').allTextContents();
  console.log(allTitles);




})

test('Testcase-3- wait and wait for', async ({ browser }) => {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.demoblaze.com/");

  await expect(page).toHaveTitle("STORE");

  await page.locator(".nav-link").nth(0).click();



  //Using wait for load state
  //  await page.waitForLoadState('networkidle');

  //wait until the element is visible
  await page.locator('.card-title').first().waitFor();
  const allTitles = await page.locator('.card-title').allTextContents();

  console.log(allTitles);




})


test('TestCase-4 Select, radio buttons, check box', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();

  //Select - Using Select tag
  await page.goto("https://www.tutorialspoint.com/selenium/practice/select-menu.php");
  const dropwdown1 = await page.locator('.form-select');
  await dropwdown1.selectOption('Mrs.');

  //For custom dropdown
  await page.locator(".mbsc-ios").nth(1).click();
  await page.locator("[role='option']").filter({ hasText: "Movies, Music & Games" }).click();
  await page.locator("[role='option']").filter({ hasText: "Home, Garden & Tools" }).click();
  await page.keyboard.press("Escape");



  //Radio Button
  await page.goto("https://www.tutorialspoint.com/selenium/practice/radio-button.php");
  await expect(page).toHaveTitle("Selenium Practice - Radio Button");
  await page.locator('.form-check-input').first().click();

  expect(page.locator('.form-check-input').first()).toBeChecked();
  console.log(await page.locator('.form-check-input').first().isChecked());
  expect(await page.locator('.form-check-input').first().isChecked()).toBeTruthy();







  //CheckBox
  await page.goto("https://www.tutorialspoint.com/selenium/practice/check-box.php");
  await page.locator("[type='checkbox']").nth(0).click();
  await page.locator("[type='checkbox']").nth(11).click();

  await expect(page.locator("[type='checkbox']").first()).toBeChecked();
  console.log(await page.locator("[type='checkbox']").nth(0).isChecked());

  await expect(page.locator("[type='checkbox']").nth(11)).toBeChecked();
  console.log(await page.locator("[type='checkbox']").nth(11).isChecked());

  //Uncheck
  console.log("Uncheck");

  await page.locator("[type='checkbox']").first().uncheck();
  await page.locator("[type='checkbox']").nth(11).uncheck();

  await expect(page.locator("[type='checkbox']").first()).not.toBeChecked();
  console.log(await page.locator("[type='checkbox']").first().isChecked());


  expect(await page.locator("[type='checkbox']").nth(11).isChecked()).toBeFalsy();
  console.log(await page.locator("[type='checkbox']").nth(11).isChecked());


})

test('Test Case -5 New Window', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/browser-windows.php");


  const [newpage] = await Promise.all(

    [context.waitForEvent('page'),
    page.locator("[title='New Tab']").click()]

  )
  await expect(newpage).toHaveTitle("Selenium Practice - Web Tables");
  const PageText = await newpage.locator("h1.mb-3").textContent();
  console.log("New page Text: " + PageText);

  await page.pause();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/text-box.php");
  await page.locator("#fullname").fill("DeepakShankar");
  const InputStr = await page.locator("#fullname").inputValue();
  console.log("Input String " + InputStr);


  //  await page.pause();


})

test('Test Case -6 Locator Chaining,Locator- Text and Text using tag, waitfor()', async function ({ browser }) {



  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.demoblaze.com/");

  //Locator Chaining
  await page.locator("#tbodyid").locator('.card-title').first().waitFor();
  console.log(await page.locator("#tbodyid").locator('.card-title').allTextContents());

  //Using Text
  await page.locator("#tbodyid").locator("text='Nokia lumia 1520'").click();
  await page.locator("h2:has-text('Nokia lumia 1520')").waitFor();
  //Using Tags and some examples
  // const NokiaText= await page.locator("h2",{hasText:"Nokia lumia 1520"}).isVisible();
  // const NokiaText= await page.locator("h2").filter({hasText:'Nokia lumia 1520'}).isVisible() 
  const NokiaText = await page.locator("h2:has-text('Nokia lumia 1520')").isVisible();
  console.log(NokiaText);
  expect(NokiaText).toBeTruthy();
  const checking = await expect(page.locator('#tbodyid .name')).toHaveText('Nokia lumia 1520')






  // await page.pause();

})

test('TestCase-7 Auto Fill actions', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/auto-complete.php");

  const Seq = await page.locator(".ui-autocomplete-input")
  await Seq.pressSequentially('java', { delay: 200 });
  await page.locator('.ui-menu-item-wrapper').nth(1).click();


})

test('TestCase-8 getbyLocators', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();

  //getByLabel()
  await page.goto("https://practice.expandtesting.com/radio-buttons");
  await page.getByLabel("Red").check();

  //getByPlaceHolder()
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  await page.getByPlaceholder("First Name").fill("Deepak");

  //getByTitle()
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  await page.getByTitle('back to Selenium Tutorial').click();

  //getbyText()- Ex -1
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  const ShowingText = await page.getByText("Selenium - Automation Practice Form").isVisible();
  console.log(ShowingText);
 
  await expect(ShowingText).toBeTruthy();
  expect(await page.getByText("Selenium - Automation Practice Form")).toHaveText("Selenium - Automation Practice Form");

  //getbyText()- Ex- 2
  await page.goto("https://www.tutorialspoint.com/selenium/practice/login.php");
  await page.getByText("New User").click();

  //getByRole()-Recommonded
  await page.goto("https://www.demoblaze.com/index.html");
  await page.getByRole("link", { name: "Contact" }).click();

  await page.goto("https://www.tutorialspoint.com/selenium/practice/text-box.php");
  await page.getByRole("button", { name: "Submit" }).click();
  const CartTxt = await page.getByRole("button", { name: "Submit" }).isVisible();
  console.log(CartTxt);

  //await page.pause();


})

test('Test Case 9- TimeOut- All Examples', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();

  //Test Level TimeOut to complete the Test
  test.setTimeout(60000);

  //Test level config for assertion (Used in 2.Test Level TimeOut)
  const NewExpect = expect.configure({ timeout: 60000 });


  //1. Step- Level Timeout for Assertion- Default Time is 40 Second in Config file. Now we are adding more Time
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  let ShowingText = await page.getByText("Selenium - Automation Practice Form").isVisible();
  console.log(ShowingText);
  await expect(ShowingText)
  await expect(page.getByText("Selenium - Automation Practice Form")).toBeVisible({ timeout: 60000 })

  //2.Test Level TimeOut (NewExpect- we can Reuse anywhere for multiple lines in this Test)
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  ShowingText = await page.getByText("Selenium - Automation Practice Form").isVisible();
  console.log(ShowingText);
  await expect(ShowingText)
  await NewExpect(page.getByText("Selenium - Automation Practice Form")).toBeVisible();

  //3.Navigation Timeout- Step level TimeOut for Navigation
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php", { timeout: 10000 });

  //4.Action TimeOut- Step Level Time out for action
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  await page.getByTitle('back to Selenium Tutorial').click({ timeout: 10000 });



})

test('TestCase 9.1- Assertion TimeOut:  Step, Test and Config Ex', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();

  const NewExpect = expect.configure({ timeout: 7000 })

  //1.Actual TimeOut for Assertion is 5 Seconds in the Config file
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  let ShowingText = await page.getByText("Selenium - Automation Practice Form").isVisible();
  console.log(ShowingText);
  await expect(ShowingText)
  await expect(page.getByText("Selenium - Automation Practice Form")).toBeVisible({ timeout: 7000 })

  //2.Actual TimeOut for Assertion is 5 Seconds in the Config file- we are declaring TestLevel TimeOut for Assertion
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  ShowingText = await page.getByText("Selenium - Automation Practice Form").isVisible();
  console.log(ShowingText);
  await expect(ShowingText)
  await NewExpect(page.getByText("Selenium - Automation Practice Form")).toBeVisible();

  /*Prirority order:
     1.Step level
     2.Test Level
     3.Config Level
     */




})

test('TestCase 9.2- Navigation TimeOut:  Step and Config Ex', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();


  //1.Step Level navigation TimeOut- Actual TimeOut for Navigation is  10000, if nothing Declared in Config then it will use "timeout"(30*1000)
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php", { timeout: 12000 })

  //2.Navigation TimeOut- Actual TimeOut for Navigation is  10000, if nothing Declared in Config then it will use "timeout"(30*1000)
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");

  /*Prirority order:
   1.Step level
   2.Config Level (use:)
   3.Config Level (timeout:)
   */



})

test('TestCase 9.3- Action TimeOut:  Step and Config Ex', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();



  //1.Action TimeOut- Step Level Time out for action
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  await page.getByTitle('back to Selenium Tutorial').click({ timeout: 10000 });

  //2.Action TimeOut- Config level TimeOut for action
  await page.goto("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
  await page.getByTitle('back to Selenium Tutorial').click();

  /*Prirority order:
     1.Step level
     2.Config Level (use:)
     3.Config Level (timeout:)
     */



})


test('TestCase-10 Hidden Text, Forward and Backward', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/check-box.php");
  await page.goBack();
  await page.goForward();
  await expect(page.locator("[type='checkbox']").nth(0)).toBeVisible();
  console.log(await page.locator("[type='checkbox']").nth(1).isHidden());
  await expect(page.locator("[type='checkbox']").nth(1)).toBeHidden();

})

test('TestCase-11 Alert box and MouseHover', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/alerts.php");

  //Accepting the dialog
  await page.on('dialog', dialog => dialog.accept())
  await page.getByRole("button", { name: "Alert" }).nth(1).click();

  //Accept after 5 Seconds
  await page.on('dialog', dialog => dialog.accept())
  await page.getByRole("button", { name: "Click Me" }).nth(0).click();

  //Dismiss
  await page.on('dialog', dialog => dialog.dismiss())
  await page.getByRole("button", { name: "Click Me" }).nth(1).click();

  //Entering Text
  await page.on('dialog', dialog => dialog.accept("Deepak"))
  await page.getByRole("button", { name: "Click Me" }).nth(2).click();


  await page.pause()
})

test('TestCase-12- Frames', async function ({ browser }) {

  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto("https://www.tutorialspoint.com/selenium/practice/frames.php");
  const newpage = await page.frameLocator("[src='new-tab-sample.php']").nth(0)
  await newpage.getByTitle("back to Selenium Tutorial").click();
  // await page.pause();

})

test.only('TestCase-13 Screenshots', async function ({ browser }) {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('https://www.demoblaze.com/');
  await page.getByRole('link', { name: 'Log in' }).click();
  await page.locator('#loginusername').click();
  await page.locator('#loginusername').fill('DeepakShankar');
  await page.locator('#loginpassword')
  await page.locator('#loginpassword').fill('Deepak@123');
  (await page).screenshot({path:'PageScreenshot.png'})
  await page.getByRole('button', { name: 'Log in' }).screenshot({path:'locatorScreenshot.png'})

  //Compare Screenshot
  await page.goto('https://www.google.com/');
  expect(await page.screenshot()).toMatchSnapshot('PageScreenshot_2.png')


})






