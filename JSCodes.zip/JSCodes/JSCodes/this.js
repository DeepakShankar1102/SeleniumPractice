//This will throw error, since Name declared outside the method
/*let person1={

    name:"Deepak",
  
    method1(){
        console.log("Name "+name);
        
    }
}
person1.method1()*/
/*
//name="Deepak"
let person1={

   name:"Deepak",
  
    method1(){
      //  console.log("Name1 "+name);//This wont work (it will work if it declared globally)
        console.log("Name1 "+person1.name);
        console.log("Name1 "+this.name);
        
    },

    method2(){

    console.log("Name2 "+this.name);

    }
}
console.log(person1.name);

person1.method1()
person1.method2()


//Example with Class and method
 
//ClassName="Deepak_Shankar"
class student1{
    ClassName="Deepak_Shankar"
    Classmethod1(){
      // let ClassName="Deepak_Shankar"
     // console.log("Class Print "+ClassName);//This wont work (it will work if it declared globally or Declared inside the method)
        console.log("Class Print1 "+this.ClassName);// This wont work if it is Declared inside the method , work only when declared globally
        
    }

    Classmethod2(){
          console.log("Class Print2 "+this.ClassName);
    }
}

let obj1=new student1()
obj1.Classmethod1()
obj1.Classmethod2()

*/


//class with Constructor and Method

class student2{
name2= "Class and Const"
name3= "New name"
    constructor(){

        console.log("class with Constructor and Method");
        console.log(" "+this.name2);
        console.log(" "+this.name3);
        
        

    }

    method1(){

        console.log("Method name1 "+this.name2);
        console.log("Method name1 "+this.name3);
        

    }

    method2(){
           console.log("Method name2 "+name2);

    }
}

let obj2=new student2// Constructor run automatically while calling object (only constructor will run not methods)
//console.log(obj2.name2);---> we can call each names after creating object
obj2.method1()
obj2.method2()




 

