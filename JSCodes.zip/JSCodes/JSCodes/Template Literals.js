let name="Deepak"

let Url='101'

let a=10
let b=15

console.log("The name is "+ name);

console.log(`The new name is ${name}`);

console.log(`The Url is https:google/com/${101}`);

console.log(`Result is  ${a+b}` );

function Fn1 () {

   name="New Name"
   return `${name}`
    
}

console.log(Fn1());




function greet(name){
    return `Hello ${name}`;
}

console.log(`${greet("Deepak")}`);


console.log
(`Hi
  Hello 
  HRU`);





