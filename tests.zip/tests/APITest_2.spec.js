const {expect,request,test} = require('@playwright/test');
const { json } = require('node:stream/consumers');

let webContext;

/*test.beforeAll('before All ', async({browser})=>{
  
  const context= await browser.newContext();
  const page= await context.newPage();
  await page.goto('https://www.demoblaze.com/');
  await page.getByRole('link', { name: 'Log in' }).click();
  await page.locator('#loginusername').click();
  await page.locator('#loginusername').fill('DeepakShankar');
  await page.locator('#loginpassword').click();
  await page.locator('#loginpassword').fill('Deepak@123');
  await page.getByRole('button', { name: 'Log in' }).click();
  

   await context.storageState({path:'state_1.json'});
   webContext=await browser.newContext({storageState:'state_1.json'});


})
*/
test('TC-1 Faking Response ', async ({browser})=>{

    //Login Using UI and Viewing Cart Using API
  const context= await browser.newContext();
  const page= await context.newPage();
  await page.goto('https://www.demoblaze.com/');
  await page.getByRole('link', { name: 'Log in' }).click();
  await page.locator('#loginusername').click();
  await page.locator('#loginusername').fill('DeepakShankar');
  await page.locator('#loginpassword').click();
  await page.locator('#loginpassword').fill('Deepak@123');
  await page.getByRole('button', { name: 'Log in' }).click();
  await page.getByRole('button', { name: 'Log in' }).click();


   const response=await page.request.post('https://api.demoblaze.com/viewcart',
      {
        data:{
          
           cookie: "RGVlcGFrU2hhbmthcjE3ODYxNzA=",
           flag: true
           
        }

      }

   );
   const PostResp=await response.json();
   console.log(PostResp.Items[0].cookie);



   await page.goto('https://www.demoblaze.com/cart.html')
   //await page.getByRole('link', { name: 'Cart' }).click();
   await expect(page.getByRole('link', { name: 'Delete' })).toBeVisible();
   

 
  

   await page.route('https://api.demoblaze.com/viewcart',
    route=>{
    const response_1=    page.request.fetch(route.request())
   
    let fake_Response_1  = {Items:[]}
     let fake_Response_2 = JSON.stringify(fake_Response_1)
     console.log(response_1);
      console.log(fake_Response_2);
    route.fulfill(
        response_1,
        fake_Response_2

    )

    }

    
    )



   await page.goto('https://www.demoblaze.com/cart.html')
   //await page.getByRole('link', { name: 'Cart' }).click();
   await expect(page.getByRole('link', { name: 'Delete' })).not.toBeVisible();

  
 //  await page.pause();
   


    




})

test.only('TC-3 Faking Request ', async ({browser})=>{

 //Login Using UI and Viewing Cart Using API
  const context= await browser.newContext();
  const page= await context.newPage();
  await page.goto('https://www.demoblaze.com/');
  await page.getByRole('link', { name: 'Log in' }).click();
  await page.locator('#loginusername').click();
  await page.locator('#loginusername').fill('DeepakShankar');
  await page.locator('#loginpassword').click();
  await page.locator('#loginpassword').fill('Deepak@123');
  await page.getByRole('button', { name: 'Log in' }).click();

  
  

   const response=await page.request.post('https://api.demoblaze.com/viewcart',
      {
        data:{
          
           cookie: "RGVlcGFrU2hhbmthcjE3ODYxNzA=",
           flag: true
           
        }

      }

   );
   const PostResp=await response.json();
   console.log(PostResp.Items[0].cookie);



   await page.goto('https://www.demoblaze.com/cart.html')
   //await page.getByRole('link', { name: 'Cart' }).click();
   await expect(page.getByRole('link', { name: 'Delete' })).toBeVisible();
   

 
   
   await page.route('https://api.demoblaze.com/viewcart',
    route=>
        {
            route.continue({url:'https://api.demoblaze.com/view'})

        }

    
    )

    await page.goto('https://www.demoblaze.com/cart.html')

   

  
  // await page.pause();
   

  
  
   
})

test('TC-3 Faking CSS & images ', async ({browser})=>{

 
  const context= await browser.newContext();
  const page= await context.newPage();
  await page.route('**/*.{css,jpg,jpeg,png}',
    route=>route.abort()
  )

  
  await page.goto('https://www.demoblaze.com/');
  await page.pause();

 
   

 })


 test('TC-4 request Listeners ', async ({browser})=>{

 
  const context= await browser.newContext();
  const page= await context.newPage();
  
  page.on('request', request=> console.log(request.url()))
  page.on('response', response=> console.log(response.url(), response.status()))
  
  await page.goto('https://www.demoblaze.com/');
  await page.getByRole('link', { name: 'Log in' }).click();
  await page.locator('#loginusername').click();
  await page.locator('#loginusername').fill('DeepakShankar');
  await page.locator('#loginpassword').click();
  await page.locator('#loginpassword').fill('Deepak@123');
  await page.getByRole('button', { name: 'Log in' }).click();
  
  await page.getByRole('link', { name: 'Cart' }).click();
  await expect(page.getByRole('link', { name: 'Delete' })).toBeVisible();
  await page.pause();

 
   

 })


