//Var can be Reclared and Re assigned

var name="IBS"
console.log("Variable name1 " +name);

var name="Software"
console.log("Variable name2 " +name); //Re Declared

//Re assigned

var varage=26
console.log("Variable age1 " +varage);

varage=27
console.log("Variable age1 " +varage);

//function Scope- only work when it is inside the function

//1.Declared inside the function and printing inside
function fn1(){
    var a= 10
    console.log("Val of a "+ a);
    
}
fn1()

//2.Declared Outside the function and Printing inside the function
var b=15 // we can use it anywhere
function fn2(){
    
console.log("Val of b "+ b);

}
fn2()

/*
//3.Declared Inside the function and Printing Outside the function
function fn3(){
var c=20


}
console.log("Val of c "+ c);// it will throw reference Error
fn3()*/


//Problem with var
//Inside blocks (if, for, while) it is NOT block scoped.






//let
//Can be Re assigned
let letage1= 25;
console.log("Let Age1 " +letage1);
letage1=30;
console.log("Let Age1 " +letage1);

//Cannot be Re declared
let letage2= 35;
console.log("Let Age2 " +letage2);
/*let letage2=40;
console.log("Let Age2 " +letage2);// It will throw Ref error */


//Block Scope
{

    let city = "Chennai";
    
console.log(city);
}



//Const

/*
//Cannot be Re Declared
const text1= "Const Val1";
console.log("Const Val1 " +text1);
const text1= "Const Val2";
console.log("Const Val2 " +text1);



//Cannot be Re assigned
const text2= "Const Val3";
text2="Const Val4"
console.log("Const Val3 " +text2);

*/



//const
const text= "const validations";
//text='Two';==> we could not proceed this
console.log(text);

//Boolen
let active=true;
console.log(!active);

let empty=null;
let empty1;
console.log(empty);
console.log(empty1);


//Function Scope- Var- we can use Declared var anywhere inside the Function and Blocks

function fn2(){
var VarFn1=10

{
    console.log("Printing Var1 "+VarFn1);
    
}

 console.log("Printing Var2 "+VarFn1);
}

fn2()

//Block Scope- Declared inside Function and use it in Both Function and blocks
function fn3(){

    let VarFn2=20
    {
       console.log("Printing Var3 "+VarFn2); 
    }

     console.log("Printing Var3 "+VarFn2); 
}
fn3()
/*
//Declared inside Block and use it in Both Function and blocks
function fn4(){

   
    {
        let VarFn3=20
       console.log("Printing Var4 "+VarFn3); 
    }

     console.log("Printing Var4 "+VarFn3); 
}
fn4()*/



for (var i = 1; i <= 3; i++) {
   console.log(i);
}

console.log(i);
