const {test, expect,request}=require('@playwright/test')

test('Tc-', async({browser})=>{

  const context= await browser.newContext();
  const page   = await context.newPage();

  await page.goto("https://www.amazon.in/");
  await expect(page).toHaveTitle("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in");
  const drp=await page.locator('#searchDropdownBox');
  drp.selectOption('Amazon Fresh Meat');

})

test('API', async ({request})=>{

 const ApiReq=await request.newContext();

 const Resp=awaitApiReq.get('https://dummyjson.com/products/1');

 Resp.json();

 expect(Resp.ok()).tobe


})