//Callback Functions

function fn1(Callback){

    console.log("Normal Function");
    Callback()
    

}

function fn2(){

    console.log("Callback Function");
    
}

fn1(fn2)


//Anonymous Callback
function main(Callback) {
    console.log("Main fn");
    Callback();
}

//main(function)-- instead of this using below
main(function () {
    console.log("Callback fn");
});

//callback with params
function fn3(Callback){

    let name1="IBS"
    let Surname1="Software"
    console.log("Using Params ");
   
    Callback(name1,Surname1)
   

}
function fn4(name2,surname2){

    console.log("Callback using params "+name2+ " and "+surname2);
    
}

fn3(fn4)


//Callback with Return value

function fn5(callback){

 
    callback()

}

function fn6(){

    let a;
    let b;
    let c=a+b
    return c

}

fn5(fn6)
