


//Async await

console.log("Async and await 1");
console.log("Async and await 2");

let fn2=()=>{
let PR2=new Promise((resolve,reject)=>{

    setTimeout(() => {

        resolve("Async and await 3- Timeout")

       
        
        
    }, 2000);
       
   
    
})

return PR2
}



async function fn3() {

   let ret= await fn2()
   console.log(ret);
   
    console.log("Async and await 4");
    
    
} 

fn3()




//To avoid this we are using asyn and await





 