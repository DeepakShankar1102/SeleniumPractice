const ExcelJs = require('exceljs')

const keyvalues = { rowNum: 1, columnNum: 1 }

//1.Simple Reading Excel file
async function Fn1() {


    const Workbook = new ExcelJs.Workbook();
    await Workbook.xlsx.readFile('/Playwright_automation_2/test_resources/download.xlsx')
    const worksheet = Workbook.getWorksheet('Sheet1')
    const worksheetRow = worksheet.getRow(3);
    const worksheetCell = worksheetRow.getCell(2, 4);
    const CellValue = worksheetCell.value;
    console.log(CellValue);


}

//Fn1()

//2.Getting all rows and columns
async function Fn2() {
    const Workbook = new ExcelJs.Workbook();
    await Workbook.xlsx.readFile('/Playwright_automation_2/test_resources/download.xlsx');
    const worksheet = Workbook.getWorksheet('Sheet1');
    worksheet.eachRow((row, rowNumber) => {

        row.eachCell((cell, cellNumber) => {
            console.log(cell.value);

        })


    })

}

Fn2()

//3.Replacing one value
async function Fn3() {

    const Workbook = new ExcelJs.Workbook();
    await Workbook.xlsx.readFile('/Playwright_automation_2/test_resources/download.xlsx');
    const worksheet = Workbook.getWorksheet('Sheet1');
    const cell = worksheet.getCell(4, 2);
    const cellvalue = cell.value;
    console.log(cellvalue);

    if (cellvalue == "Papaya") {

        cell.value = "Lemon";
        await Workbook.xlsx.writeFile("download.xlsx");
        console.log(cell.value);
    }



}
//Fn3()

//4.Using object value assigning cell values

async function Fn4() {

    const Workbook = new ExcelJs.Workbook();
    await Workbook.xlsx.readFile('/Playwright_automation_2/test_resources/download.xlsx')
    const worksheet = Workbook.getWorksheet("Sheet1");

    worksheet.eachRow((row, rowNumber) => {

        row.eachCell((cell, cellNumber) => {

            if (cell.value == "Banana") {

                keyvalues.rowNum = rowNumber;
                keyvalues.columnNum = cellNumber;

                console.log( keyvalues.rowNum );
                console.log( keyvalues.columnNum );


            }


        })

    })

    
     const cell=  worksheet.getCell(keyvalues.rowNum,keyvalues.columnNum )
        cell.value = "Guva";
        await Workbook.xlsx.writeFile("/Playwright_automation_2/test_resources/download.xlsx");
        console.log(cell.value);


}

//Fn4();
 

