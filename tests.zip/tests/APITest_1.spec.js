const{test,expect,request} =require('@playwright/test');

let webContext;
test.beforeAll(async ({browser})=>{
   const context= await browser.newContext();
   const page=await context.newPage();

   await page.goto("https://demo.cyclos.org/ui/login");
   await page.locator("[placeholder='User']").fill("DeepakShankar99");
   await page.locator("[type='password']").fill("Deepak@123");
   await page.locator("text='Submit'").click();
   await expect(page).toHaveTitle("Dashboard - Cyclos");
   await context.storageState({path:'state.json'});
   webContext=await browser.newContext({storageState:'state.json'});  

})

test('TC-1 check Title',async ()=>{
 const page=await webContext.newPage();
 await page.goto("https://demo.cyclos.org/ui/dashboard");
 await expect(page).toHaveTitle("Dashboard - Cyclos");
 })

test('TC-2 Click Pay User ',async ()=>{


 const page=await webContext.newPage();
 await page.goto("https://demo.cyclos.org/ui/dashboard");
 await page.locator(".quick-access-icon").first().click();


})
