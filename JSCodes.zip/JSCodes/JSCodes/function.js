
//Function 1
function traditional(){
    console.log("Traditional Method 1");
} 

traditional();

//Function  Using Param
function traditionalwithPM(Uname,Pwd){
    console.log("with param "+Uname,Pwd);
}
traditionalwithPM("Deepak","Shankar");

//Function Using return value 1
function TradwithRet(){
    let a=5;
    let b=10;
    let c=a+b;
    return c;
}

console.log(TradwithRet());


//Function Using return value 2
function TradwithRet2(a,b){
    let c=a+b;
    return c;
}

console.log(TradwithRet2(100,200));


//Storing in Variables
let greet = function(){

    console.log("Hello1");
};
greet();

greet = function(){

    console.log("Hello2");
};

greet();

//Hoisting difference
hello();

function hello(){

    console.log("Hello");
}

//Hoisting using declarations
hello1();

let hello1=function(){

    console.log("Hello");
}



//Arrow Functions- No need to use Function keyword
Newwaywo= ()=>{
console.log("New Method wo const and Let");
}
Newwaywo();


let Newway= ()=>{
console.log("New Method");
}
Newway();


Newway= ()=>{
console.log("New Method Reassignment");
}
Newway();


//Arrow Functions- Using Param - Let allow to do a Re assignement if we Use const it wont allow Reassignement

const Newway1= (Uname,Pwd)=>{
    console.log("New method param " +Uname,Pwd);
}
Newway1("Deepak","Shankar");

/*Newway1= (Uname,Pwd)=>{
    console.log("New method param222 ", Uname,Pwd);
}

Newway1("Deepak","Shankar");*/

