# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: POM_1.spec.js >> @POM-4 Using Template literals DeepakShankar99
- Location: tests\POM_1.spec.js:59:1

# Error details

```
Error: expect(page).toHaveTitle(expected) failed

Expected: "Dashboard - Cyclosss"
Received: "Dashboard - Cyclos"
Timeout:  5000ms

Call log:
  - Expect "toHaveTitle" with timeout 5000ms
    6 × locator resolved to <html lang="en">…</html>
      - unexpected value "Login - Cyclos"
    - locator resolved to <html lang="en">…</html>
    - unexpected value "Cyclos"
    6 × locator resolved to <html lang="en">…</html>
      - unexpected value "Dashboard - Cyclos"

```

```yaml
- navigation:
  - link "Close":
    - /url: "#"
    - img
  - text: Cyclos
  - link "Login":
    - /url: "#"
    - img
- link "Dashboard":
  - /url: /ui/
  - img
  - text: Dashboard
- text: Banking
- link "Member account":
  - /url: /ui/banking/self/account/memberaccount
  - img
  - text: Member account
- link "Payment to user":
  - /url: /ui/banking/self/payment
  - img
  - text: Payment to user
- link "Receive QR-code":
  - /url: /ui/banking/qr
  - img
  - text: Receive QR-code
- link "Receive payment":
  - /url: /ui/banking/pos
  - img
  - text: Receive payment
- link "Scheduled payments":
  - /url: /ui/banking/self/installments
  - img
  - text: Scheduled payments
- link "Payment requests":
  - /url: /ui/banking/self/payment-requests
  - img
  - text: Payment requests
- link "Tickets":
  - /url: /ui/banking/self/tickets
  - img
  - text: Tickets
- link "Voucher redeems":
  - /url: /ui/banking/self/voucher-transactions
  - img
  - text: Voucher redeems
- text: Marketplace
- link "Business directory":
  - /url: /ui/users/search
  - img
  - text: Business directory
- link "Advertisements":
  - /url: /ui/marketplace/search
  - img
  - text: Advertisements
- link "Advertisement interests":
  - /url: /ui/login
  - img
  - text: Advertisement interests
- link "My vouchers":
  - /url: /ui/banking/self/vouchers
  - img
  - text: My vouchers
- link "My advertisements":
  - /url: /ui/login
  - img
  - text: My advertisements
- link "Unanswered questions":
  - /url: /ui/login
  - img
  - text: Unanswered questions
- link "Invite users":
  - /url: /ui/personal/invite
  - img
  - text: Invite users
- text: Information
- link "About Cyclos":
  - /url: /ui/page/about
  - img
  - text: About Cyclos
- link "Stats & Charts":
  - /url: /ui/page/7762070814184102463
  - img
  - text: Stats & Charts
- link "Contact form":
  - /url: /ui/page/contact
  - img
  - text: Contact form
- link "Google calendar":
  - /url: /ui/page/calendar
  - img
  - text: Google calendar
- link "Help":
  - /url: /ui/help
  - img
  - text: Help
- text: Personal
- link "My profile":
  - /url: /ui/users/self/profile
  - img
  - text: My profile
- link "Edit profile":
  - /url: /ui/users/self/profile/edit
  - img
  - text: Edit profile
- link "Settings":
  - /url: /ui/personal/settings
  - img
  - text: Settings
- link "Contacts":
  - /url: /ui/users/contacts
  - img
  - text: Contacts
- link "Password":
  - /url: /ui/users/self/passwords
  - img
  - text: Password
- link "Documents":
  - /url: /ui/users/documents
  - img
  - text: Documents
- link "NFC cards":
  - /url: /ui/users/self/tokens/7762070814177996095
  - img
  - text: NFC cards
- link "QR / bar codes":
  - /url: /ui/users/self/tokens/7762070814177995839
  - img
  - text: QR / bar codes
- link "Messages":
  - /url: /ui/users/messages/search
  - img
  - text: Messages
- link "Notifications":
  - /url: /ui/personal/notifications
  - img
  - text: Notifications
- link "References":
  - /url: /ui/users/self/references/search
  - img
  - text: References
- link "Quick access settings":
  - /url: /ui/users/self/quick-access/settings
  - img
  - text: Quick access settings
- navigation:
  - link "Cyclos":
    - /url: /ui/
    - img
    - text: Cyclos
  - link "Dashboard":
    - /url: /ui/
    - img
    - text: Dashboard
  - link "Banking":
    - /url: /ui/banking/self/account/memberaccount
    - img
    - text: Banking
  - link "Marketplace":
    - /url: /ui/users/search
    - img
    - text: Marketplace
  - link "Information":
    - /url: "#"
    - img
    - text: Information
  - link "DeepakShankar9…":
    - /url: /ui/users/self/profile
    - img
    - text: DeepakShankar9…
  - link "Messages":
    - /url: /ui/users/messages/search
    - img
  - link "Notifications":
    - /url: /ui/personal/notifications
    - img
  - link "Help":
    - /url: "#"
    - img
  - link "Logout":
    - /url: "#"
    - img
- text: Quick access
- button "Customize":
  - img
  - text: Customize
- link "Pay user":
  - /url: /banking/self/payment
  - img
  - text: Pay user
- link "Receive payment":
  - /url: /banking/pos
  - img
  - text: Receive payment
- link "Directory":
  - /url: /users/search
  - img
  - text: Directory
- link "Contacts":
  - /url: /users/contacts
  - img
  - text: Contacts
- link "Messages":
  - /url: /users/messages/search
  - img
  - text: Messages
- link "Switch theme":
  - /url: /personal/settings
  - img
  - text: Switch theme
- text: Account status
- button "View":
  - img
  - text: View
- text: Balance 500,00 IU's
- img: May Jun Jul Aug Sep Now 501 500
- heading "Last payments" [level=3]
- table:
  - row "19/11/2023 Debit account 500,00 IU's":
    - cell "19/11/2023"
    - cell "Debit account"
    - cell "500,00 IU's"
- text: Latest advertisements
- button "View":
  - img
  - text: View
- link "Programo sites":
  - /url: /ui/marketplace/view/7762070814176551487
- link "faço baby sitting":
  - /url: /ui/marketplace/view/7762070814176564287
- link "Sell The Tiger":
  - /url: /ui/marketplace/view/7762070814176335167
- link "Wana eat 5 Star?":
  - /url: /ui/marketplace/view/7762070814176332607
- link "Music fest":
  - /url: /ui/marketplace/view/7762070814176332351
- link "hamster":
  - /url: /ui/marketplace/view/7762070814176332095
- text: Upcoming events Tue May 1 2023 Workers holiday Cyclos office closed for this day Fri Jun 14 2023 Cyclos meeting New exciting plans for the next Cyclos version! test Thu Aug 15 2023 Summer summit Yearly Cyclos summer camp Tue Dec 25 2023 Christmas day Christmas dinner at eight o'clock This is an example of a content page. It can be changed by an administrator
- link "Cyclos software":
  - /url: https://www.cyclos.org
- link "Documentation":
  - /url: https://documentation.cyclos.org
- link "Forum":
  - /url: https://forum.cyclos.org
- link "Wiki":
  - /url: https://wiki4.cyclos.org/
```

# Test source

```ts
  1  | const {test, expect}=require('@playwright/test');
  2  | const {LoginPage}=require('./POM/Login_Page.spec')
  3  | const {POM_Manager}=require('./POM/POM_Manager.spec');
  4  | const { log } = require('node:console');
  5  | const dataset=JSON.parse(JSON.stringify((require("./POM/POM_1.json"))))
  6  | const dataset2=JSON.parse(JSON.stringify((require("./POM/POM_2.json"))))
  7  | 
  8  | //To Run Parallel
  9  | test.describe.configure({mode:'parallel'})
  10 | test('POM -1 withot POM Manager', async({browser})=>{
  11 | 
  12 |   const context= await browser.newContext();
  13 |   const page=await context.newPage();
  14 | 
  15 |   const loginCred=new LoginPage(page);
  16 |   
  17 |   await loginCred.url("https://demo.cyclos.org/ui/login")
  18 |   await loginCred.validLogin("DeepakShankar99","Deepak@123")
  19 |   
  20 |   await expect(page).toHaveTitle("Dashboard - Cyclos");
  21 | 
  22 |   
  23 | 
  24 | })
  25 | 
  26 | test('POM -2 with POM Manager', async({browser})=>{
  27 | 
  28 |   const context= await browser.newContext();
  29 |   const page=await context.newPage();
  30 | 
  31 |   const login=new POM_Manager(page);
  32 | 
  33 |   const loginCred= login.getloginpage();
  34 | 
  35 |   await loginCred.url("https://demo.cyclos.org/ui/login")
  36 |   await loginCred.validLogin("DeepakShankar99","Deepak@123")
  37 |   
  38 |   await expect(page).toHaveTitle("Dashboard - Cyclos");
  39 | 
  40 |   
  41 | 
  42 | })
  43 | 
  44 | 
  45 | test('POM-3 Using DataSet', async({browser})=>{
  46 | 
  47 |   console.log("POM Using dataset");
  48 |   
  49 |   const context=await browser.newContext();
  50 |   const page= await browser.newPage();
  51 | 
  52 |   const loginPage=new LoginPage(page);
  53 |   await loginPage.url(dataset.url);
  54 |   await loginPage.validLogin(dataset.username,dataset.password);
  55 |   await expect(page).toHaveTitle("Dashboard - Cyclos");
  56 | 
  57 | })
  58 | 
  59 | test(`@POM-4 Using Template literals ${dataset.username}`, async({browser})=>{
  60 | 
  61 |   console.log("POM Using dataset using Template literals");
  62 |   
  63 |   const context=await browser.newContext();
  64 |   const page= await browser.newPage();
  65 | 
  66 |   const loginPage=new LoginPage(page);
  67 |   await loginPage.url(dataset.url);
  68 |   await loginPage.validLogin(dataset.username,dataset.password);
> 69 |   await expect(page).toHaveTitle("Dashboard - Cyclosss");
     |                      ^ Error: expect(page).toHaveTitle(expected) failed
  70 | 
  71 | })
  72 | 
  73 | for(const data of dataset2){
  74 | 
  75 | test(`@POM-5 Using different dataset ${data.username}`, async({browser})=>{
  76 | 
  77 |   console.log("POM Using different dataset using Template literals");
  78 |   
  79 |   const context=await browser.newContext();
  80 |   const page= await browser.newPage();
  81 | 
  82 |   const loginPage=new LoginPage(page);
  83 |   await loginPage.url(data.url);
  84 |   await loginPage.validLogin(data.username,data.password);
  85 |   await expect(page).toHaveTitle("Dashboard - Cyclos");
  86 | 
  87 | })
  88 | 
  89 | }
  90 | 
  91 | 
  92 | 
  93 | 
  94 |   
  95 | 
```