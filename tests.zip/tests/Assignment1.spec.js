const {test, expect}=require('@playwright/test')

test('Assignment-1', async({browser})=>{

   const context= await browser.newContext();
   const page=await context.newPage();

   //Navigation
   

   await page.goto('https://eventhub.rahulshettyacademy.com');
   //Login


   await page.getByPlaceholder('you@email.com').fill('deepakgen99@gmail.com');
   await page.getByLabel('password').fill('Deepak@123');
   await page.locator('#login-btn').click();

 await page.pause();
   //Navigate to Event
const [newPage] = await Promise.all([

page.context().waitForEvent('page'),

page.getByRole('link', { name: 'Events' }).click()

]);
 await newPage.pause();


   await newPage.waitForLoadState();  
   await newPage.goto('https://eventhub.rahulshettyacademy.com/admin/events');
   console.log(await page.url());

    await newPage.pause();


   const Event_Title=`Test Event ${Date.now()}`
   await newPage.locator('#event-title-input').fill(Event_Title);
   await newPage.locator('#admin-event-form textarea').fill("Text area Description");
   await newPage.getByLabel('city').fill("Chennai");
   await newPage.getByLabel('Venue').fill("Venue Address");
   await newPage.getByLabel('event-date-&-time').fill(futureDateValue());
   await newPage.getByLabel('price-($)').fill("100");
   await newPage.getByLabel('total-seats').fill("50");
   await newPage.locator('#add-event-btn').click();







   

})