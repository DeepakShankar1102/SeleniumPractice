await page.goto("https://example.com");
await page.click("#login");