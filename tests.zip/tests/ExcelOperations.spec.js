const {test, expect}=require('@playwright/test')
const ExcelJs = require('exceljs')

async function readExcel_WithText(SearchText,FileName) {
    
    const Workbook=new ExcelJs.Workbook();
    await Workbook.xlsx.readFile(FileName);
    const Worksheet = Workbook.getWorksheet('Sheet1');
        Worksheet.eachRow((row,rowNumber)=>{

        row.eachCell((cell,ColNumber)=>{
              if(cell.value==SearchText){

               
              
               console.log(rowNumber);
               console.log(ColNumber);
               
                

              }
           

        })

        
    })

  

    
    
}



test('Excel_Op_1', async ({browser})=>{

    const context= await browser.newContext();
    const page= await context.newPage();
    await  page.goto("https://rahulshettyacademy.com/upload-download-test/");
    expect(page).toHaveTitle('RS Web Table Automation Page')
   
    await page.locator('#downloadButton').waitFor();
    await page.locator('#downloadButton').click();
    await page.waitForEvent("download");
    await  readExcel_WithText("Apple",'/Users/209079/Downloads/download.xlsx')
    await page.locator('#fileinput').click();
    await page.locator('#fileinput').setInputFiles("/Users/209079/Downloads/download.xlsx")
    

})