let arr1=[10,20,30]
console.log(arr1);
console.log(...arr1);
let arr2= [...arr1] //assigning back to array
console.log(arr2);

//Adding new values
 let update1=[...arr1, 40,50]
 console.log(update1);
update1.push(60)
 console.log(update1);

 //Using String

 let name='Deepak'
console.log(...name);

 //Using Objects
 let obj1={

    name:"Deepak",
    age:"27"

 }

console.log(obj1);
console.log({...obj1});

let obj2={...obj1}
console.log(obj2);

//Adding new key values

let obj3={
    ...obj2,
    job:"IT"
}
 
console.log(obj3);

//updating existing values

let obj4={
    ...obj3,
    age:"28"
}

console.log(obj4);

//Using Function - normal

function fn1(V1,V2,V3){

let V4= V1+V2+V3
return V4;

}

console.log(fn1(10,20,30));

//Using Function - Spread operataor

let inputs=[40,50,60]

console.log(fn1(...inputs));






 
 

