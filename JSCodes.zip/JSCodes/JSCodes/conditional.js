let age='18'

if(age===18){
    console.log("eligible for Vote");
}
else if(age<18){
     console.log("Not eligible for Vote");
}
else{
  console.log("Exact Age");
}

let day = 1;

switch (day) {
   case 1:
      console.log("Monday");
      break;
   case 2:
      console.log("Tuesday");
      break;
   default:
      console.log("Invalid Day");
}

//Ternary
agess=21;
Result =(agess>=13) ? "Eligible":"Not Eligible";

console.log(Result);


