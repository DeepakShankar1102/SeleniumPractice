class C1{

    method1(){

        console.log("Method 1");
        
    }
}

class C2 extends C1{

     method2(){

        console.log("Method 2");
        
    }

}

let obj1=new C2// Using class 2 we can call both Method 1 and Method 2
obj1.method1()


//Using Constructor
class C3{

      constructor(){

       console.log("Constructor Example1");
       

    }

    method1(){

        console.log("Method 1");
        
    }
}

class C4 extends C3{

    constructor(){
        super()
        console.log("Constructor Example2"); // If child class also having constructor, then use super

    }

     method2(){

        console.log("Method 2");
        
    }

}

let obj2=new C4 // Here it will call constructor
obj2.method1()
obj2.method2()


//Using this, constructor and super

name="Deepak"
class C5{

     constructor() {
        this.name="Constructor name"
        console.log("Method 5");
        console.log(this.name);
        
        
     }
    method1(){
         this.name="Shankar"
         console.log("Method 1");
         console.log("Method 1 "+name);
         console.log("Method 1 "+this.name);
        
    }
}

class C6 extends C5{

    constructor(){
        super()
        this.name='Constructor C6 Name'
        console.log(this.name);
        
    }

}

let obj3=new C6
obj3.method1()


class C7 {

    constructor(EX1, EX2) {

        this.EX1 = EX1;
        this.EX2 = EX2;

        console.log("Parent Constructor");
        console.log(this.EX1, this.EX2);

    }

    method1() {

        console.log("Parent Method");
        console.log(this.EX1, this.EX2);

    }

}
//Using Parameter Constructor, this, calling super method
//super.method1() -- we call call paraent method from child class using super
class C8 extends C7 {

    constructor(EX1, EX2, EX3, EX4) {

        super(EX1, EX2);

        this.EX3 = EX3;
        this.EX4 = EX4;

        console.log("Child Constructor");
        console.log(this.EX3, this.EX4);

    }

    method2() {

        console.log("Child Method");
        console.log(this.EX3, this.EX4);

    }

}

let obj = new C8(
    "ParentValue1",
    "ParentValue2",
    "ChildValue1",
    "ChildValue2"
);

obj.method1();
obj.method2();




//Super: 
//Calls the parent class constructor.
//Must be called before using this in a child constructor.
//Used to initialize inherited properties.





