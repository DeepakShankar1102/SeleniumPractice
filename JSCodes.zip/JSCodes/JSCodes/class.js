//Normal Class with one method
class Example1{

    method1(){
        console.log("Normal Class with one method");
        
    }
}

let obj=new Example1()
obj.method1()//Method is running


//Class with Constructor and method
class student{

    constructor(){
        console.log("Class with Constructor and method1");
        
    }

    example1() {

        console.log("Class with Constructor and method2");
        
        
    }
    
}

let  obj1=new student() //Constructor runs automatically once the object created
obj1.example1()// Runs the method inside


//Parameterized constructor and method (store the class in variable)
const student1= class{

    constructor(name, age){

        console.log("Parameteried const name "+name);
        console.log("Parameteried const age "+age);
        
        

    }

    example2(){

        console.log("Parameterized constructor method");
    }
}

let obj3=new student1("Deepak", 27)
obj3.example2()




//Under

let person1 = {
    name: "Deepak",

    introduce() {

        
        console.log(this.name);
    }
}

let person2={
    name: "Shankar",

    introduce(){
        console.log(this.name);
        
    }
}

person1.introduce();

person2.introduce();
