 const base =require('@playwright/test')
const {request} =require('@playwright/test')

 
   exports.costumFix=base.test.extend(
{
    
         custLogin: async({browser},use)=>{

          const context = await browser.newContext();
          const page = await context.newPage();
          await page.goto("https://www.demoblaze.com/");
          await use(page)

    },

    
         ApiFix: async({},use)=>{
           const apiReq = await request.newContext();
           const response = await apiReq.get('https://dummyjson.com/products/1');
           const Jsonbody = await response.json();
           await use(Jsonbody)


    },

    testdata:{

        FixtureInput1: "Fix1"

    }

    
  


}

 )

