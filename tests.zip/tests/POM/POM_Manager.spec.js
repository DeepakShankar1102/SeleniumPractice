const {LoginPage}=require('./Login_Page.spec');

class POM_Manager{


    constructor(page){
        this.page=page;
        this.loginPage= new LoginPage(page)

    }

    getloginpage(){

        return this.loginPage;
    }
}

module.exports={POM_Manager}