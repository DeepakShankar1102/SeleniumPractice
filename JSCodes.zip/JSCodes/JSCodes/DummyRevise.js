class C1{

   constructor(a,b){
      this.a=a;
      this.b=b;


   }

   method1(){

     let c=this.a+ this.b
      console.log(c);
      

   }

}

class C2 extends C1{

    constructor(a,b,c,d){

      super(10,20)
      this.a=a
      this.b=b
      this.c=c
      this.d=d

      console.log(a,b,c,d);
      
      
   }

   method2(){
         console.log(this.a,this.b,this.c,this.d);

   }


}

let obj=new C2(
   10,
   20,
   30,
   40)

obj.method1();
obj.method2();

