const {test,request, expect}=require('@playwright/test')



test('API- GET Request TC-1 ', async () => {

    //Declare a Request
    const apiReq = await request.newContext();
    const response = await apiReq.get('https://dummyjson.com/products/1');

    //Printing JSON and JSON Values
    const Jsonbody = await response.json();
    console.log(Jsonbody);
    console.log(Jsonbody.category);
    console.log(Jsonbody.reviews[0].reviewerName);

    
   //Assert JSON 
   expect(response.ok()).toBeTruthy();
   expect(response.status()).toBe(200);
   expect(Jsonbody.category).toEqual("beauty")  
   expect(Jsonbody.reviews[0].reviewerName).toEqual("Eleanor Collins") 
   expect(Jsonbody.description).toContain("Princess");
   expect(Jsonbody.title).toMatch(/^Essence/);
   expect(Jsonbody.title).toMatch(/Princess$/);
   expect(Jsonbody.title).toMatch(/Mascara/);
   expect(Jsonbody.title).toMatch(/mascara/i);
   expect(Jsonbody).toHaveProperty("price");
   expect(Jsonbody.reviews).toHaveLength(3);
   expect(Jsonbody.weight).toBeGreaterThan(3);
   expect(Jsonbody.weight).toBeLessThan(6);
   expect(Jsonbody.weight).toBeGreaterThanOrEqual(4);
   expect(Jsonbody.weight).toBeLessThanOrEqual(4);
   expect(Jsonbody.weight).toBeDefined();//Present in JSON
   expect(Jsonbody.notbe).toBeUndefined();// Not Present
   expect(Jsonbody.category).not.toBeNull();
   expect(response.status()).not.toBe(404);


   //validate only the fields you care about
   expect(Jsonbody.dimensions).toMatchObject(

    {width: 15.14,
     height: 13.08,
    })

    //Checks whether an array contains a specific object.
  expect(Jsonbody.reviews).toContainEqual(
    {rating: 3,
    comment: "Would not recommend!",
    date: "2025-04-30T09:41:02.053Z",
    reviewerName: "Eleanor Collins",
    reviewerEmail: "eleanor.collins@x.dummyjson.com",
});
  
});

test('API- Post Request TC-2',async ()=>{

     const context = await request.newContext();
     const response= await context.post('https://jsonplaceholder.typicode.com/posts',

       { data:

         {
                title: "Playwright",
                body: "API Testing",
                userId: 2
        }
       }
     );
   
    
     const PostResp = await response.json();
     console.log(PostResp);
     expect(response.status()).toBe(201);
     expect(PostResp.id).toEqual(101);
     expect(PostResp.title).toEqual("Playwright");
     

})

test('API- Passing Headers in Request TC-3',async ()=>{

      const context = await request.newContext();
      const response= await context.get('https://demo.cyclos.org/api/self/accounts/memberaccount/data-for-history',
       {
        headers:{
            'Authorization':'Basic RGVlcGFrU2hhbmthcjk5OkRlZXBha0AxMjM=',
            'Content-type':'application/json'

        }
       }

      
     );
   
    
     const PostResp = await response.json();
     console.log(PostResp);
     expect(response.status()).toBe(200);
     expect(PostResp.preselectedPeriods[0].name).toEqual("Today");
  
})


