//1.
//import { fn1, fn2, fn3 } from "./Module1.js";// To import one by one

//2.
//import {fn1, fn1 as Rnfn1} from  "./Module1.js";// To Rename functions

//3.
//import * as Mod from "./Module1.js";// To Import all
//console.log("Print "+Mod.fn1());// To print one function from specific module

//4. Import all from export all
//import { Exp1 }  from "./Module1.js";

//5.Default Export
import fn5 from "./Module1.js"

console.log(fn5());

import {fn1 as ReFn1 }from './Module1.js';

import * as Mod from './Module2.js'




//common points
//First it will execute all from Module 1
//Then It will import to module2 and then it will execute module 2
//A file should have only one default export



