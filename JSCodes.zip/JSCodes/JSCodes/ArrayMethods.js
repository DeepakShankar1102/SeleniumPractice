let number=[1,2,3,4]

//1.Map- To Transform array
//way 1
let doubled=number.map(n=> n*2);
console.log(doubled);

//way 2
let Triple=number.map((num)=>{
    return num*3;
})
console.log(Triple)

//2.Push- Add to End
number.push(7);
console.log(number);

//3.Pop- Remove from End
number.pop();
console.log(number);

//4.Unshift-Add to Start
number.unshift(5);
console.log(number);

//5.Shift-Remove from Start
number.shift();
console.log(number);

//6.Filter- Returns elements that match condition
let Filtered=number.filter(n=> n>=3)
let Filtered1=number.filter(n=> n%2==0)
console.log("Filter 1 "+Filtered);
console.log("Filter 2 "+Filtered1);

//7.Find- Find the First Match- that match condition

let found=number.find(n=>n>1)
console.log(found);

//8.Includes-Check the presence

let status=number.includes(4)
let statusIndex=number.includes(4, 7)//check number 4 from 7th index
console.log(status);
console.log(statusIndex);

//9.Reduce-Reduces array to a single value
let reduced=number.reduce((acc,curr)=> acc+curr,0)
console.log(reduced);

//10.Slice- Copy Portion
let sliceop=number.slice(1,4)//Print value index 1,2,3 ignore the 4th
console.log(sliceop);

//11.Splice- Modify(Remove/update)

array1=["Deepak","Shankar","CSE","ACC","IBS","Unknown"]
let spliceop=array1.splice(2,3,'Added')
console.log(array1);//2nd,3rd, 4th items removed
console.log(spliceop);//Removed items
let spliceop1=array1.splice(2,2,'Added','Added2')//add mutiple items
let spliceop2=array1.splice(2)//remove everything from index 2
console.log(array1);//Give updated item
console.log(spliceop);//Give removed item
console.log(array1);

















