let arr=["Deepak", "Shankar"]

let [First_name, Last_name]=arr;

console.log(First_name);
console.log(Last_name);


//Skip Values

let arr1=["ACC", "IBS", "COMCAST"]

let [Company1, ,Company3]=arr1

console.log(Company1);
console.log(Company3);

//To Set values
let arr2=["Deepak_Shankar"]

let [name, age=27]=arr2

console.log(name);
console.log(age);


//Swap values

let a=10;
let b=20;

[b,a]=[a,b]

console.log(a);
console.log(b);

//Object Destructuring

let obj1 = {
    name_: "Deepak",
    age_: 25,
    city_: "Chennai"
};

let { name_, age_, city_,job="IT" } = obj1;

console.log(name_);
console.log(age_);
console.log(job);


//To skip- not possib;e
//let { name_, , age_ } = obj1;

//To add values

let {role="Testing"}=obj1
console.log(role);








