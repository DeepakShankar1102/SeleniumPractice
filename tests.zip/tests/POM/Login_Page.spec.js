class LoginPage{

    constructor(page){
        this.page=page
        this.username=page.locator("[placeholder='User']");
        this.password=page.locator("[type='password']");
        this.submitBtn=page.getByRole('button', { name: 'Submit' });

    }

    async url(URL){

       await this.page.goto("https://demo.cyclos.org/ui/login");

        

    }

    async validLogin(username,password){
       
        await this.username.fill(username);
        await this.password.fill(password);
        await this.submitBtn.click();
       

    }

}

module.exports={LoginPage}