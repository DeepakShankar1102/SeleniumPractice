
/*

const Exception1=(a,b)=>{

const c=a/b
return c;

}

try{
   const ans=Exception1(a,15);
   console.log(ans);
  // throw new Error ("Error thrown")
}
catch(error){
  //error.name="Declared Error";
 // console.log(error)
  console.log("Error Message "+error.message)
  console.log("Error Name "+error.name)
  //console.log(error.stack)
  console.log("Exception")
}
finally{
  console.log("Finally Block")
}
*/
//1.Basic
try{
  console.log(a)

}
catch(error){
     console.log(error.name);
     console.log(error.message);
     console.log(error.stack);
     
}
finally{
  console.log("Finally Block")
}

//2.Using throw- No errors has been thrown so manual error get printed
/*
try{
  
   throw new Error("Throw Error")
}
catch(error){
   console.log(error.message);
   console.log(error.name);
   
}
   */

/*
//3.Using throw- Error has been thrown so manual error get ignored

try{
  console.log(t)
   throw new Error("Throw Error")
}
catch(error){
   console.log(error.message);
   console.log(error.name);
   
}*/

//4.Using throw- Manual Error declaration
try{
   let age=17
   
   if(age<18)
    {
   let myError= new Error("Throw Error")
   myError.name="Specified Error"
   throw myError;

   }
}
catch(error){
   console.log(error.message);
   console.log(error.name);
   
}


